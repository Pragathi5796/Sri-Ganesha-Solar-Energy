// CONTACT AND BACKEND SETTINGS - change these first.
const CONFIG={
  WHATSAPP:'918660268890',                    // WhatsApp number with country code, no + sign
  EMAIL:'sriganeshasolarenergy@gmail.com',    // company email (also used by the backend)
  API_URL:''                                  // '' = form uses FormSubmit.  With the backend running locally use 'http://localhost:3000'
};                                            // After deploying the backend use its address, e.g. 'https://api.yourdomain.in'
