// Sri Ganesha Solar Energy - page behaviour (menu, tabs, photo slider, estimator, contact form).
// Content lives in data.js, contact settings in config.js.
// Sri Ganesha Solar Energy - page behaviour (menu, tabs, slider, estimator, form)

const $=s=>document.querySelector(s),H=(t,c,h)=>{const e=document.createElement(t);if(c)e.className=c;e.innerHTML=h||'';return e};
const ic=n=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="26" height="26">${IC[n]}</svg>`;
// ===== SERVICES (edit text here) =====

// ===== BENEFITS =====
const fill=(id,a,c)=>a.forEach((x,i)=>$(id).append(H('div','bx',`<span class="ico">${ic(x[0])}</span><div><h3>${x[1]}</h3><p>${x[2]}</p></div>`)));
fill('#svc',SVC,'sv');fill('#ben',BEN,'bn');

// ===== CUSTOMER TYPES: Residential / Commercial / Small / Large =====
SEG.forEach(x=>$('#seg').append(H('a','card',`<span class="ico">${ic(x[0])}</span><h3>${x[1]}</h3><b class="k">${x[2]}</b><p>${x[3]}</p>`)));$('#seg').querySelectorAll('a').forEach(a=>a.href='#contact');
function tabs(bar,pan,items,render){items.forEach((it,i)=>{const b=H('button','',it[0]);b.role='tab';b.onclick=()=>sel(i);$(bar).append(b)});
 function sel(i){[...$(bar).children].forEach((b,j)=>b.setAttribute('aria-selected',i==j));render(items[i],$(pan))}sel(0)}
const PR=SEG.map(x=>[x[1],x[2],x[3]]);
tabs('#pt','#pp',PR,(x,p)=>p.innerHTML=`<div class="card" style="display:flex;gap:1.5rem;flex-wrap:wrap;align-items:center"><b style="font:700 2.2rem Poppins,sans-serif;color:var(--sun)">${x[1]}</b><p style="flex:1;min-width:220px;font-size:1.05rem">${x[2]}</p><a class="btn" href="#contact" style="color:#fff">Ask for a quote</a></div>`);

// ===== TATA POWER SOLAR TABS =====
tabs('#vt','#vp',VT,(x,p)=>p.innerHTML=`<p style="max-width:70ch;font-size:1.05rem;margin:0">${x[1]}</p>`);
[["12,742","MW combined generation"],["30,000+","customers served"],["460+","MW of rooftop solar"],["30+","years of experience"],["No.1","solar EPC player, 6 years in a row (2014-2020)"]].forEach(s=>$('#stats').append(H('div','',`<b>${s[0]}</b>${s[1]}`)));

// ===== CLIENTS / KEY PROJECTS TABLE (name, industry, location, kWp, I=Industrial C=Commercial) =====
tabs('#ct','#cb',[["All projects",0],["Industrial","I"],["Commercial","C"]],(x,p)=>p.innerHTML=CL.filter(r=>!x[1]||r[4]==x[1]).map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3].toLocaleString('en-IN')}</td></tr>`).join('')+(x[1]?'':'<tr><td colspan="4">Plus other residential, commercial and industrial projects across Karnataka (50+ kWp)</td></tr>'));


// ===== GALLERY PHOTOS (files are in the images folder) =====
(()=>{const g=$('#gal');g.innerHTML='<div class="trk"></div><button class="ar l" aria-label="Previous photo">&#8249;</button><button class="ar r" aria-label="Next photo">&#8250;</button><div class="dots"></div>';
const tr=g.querySelector('.trk'),dt=g.querySelector('.dots');let k=0,tm;
IM.forEach((s,i)=>{const f=H('div','sl','<img src="'+s+'" alt="'+AL[i]+'">');f.onclick=()=>{$('#lb img').src=s;$('#lb').classList.add('on')};tr.append(f);const d=H('button','');d.setAttribute('aria-label','Photo '+(i+1));d.onclick=()=>{go(i);play()};dt.append(d)});
function go(i){k=(i+IM.length)%IM.length;tr.style.transform='translateX(-'+k*100+'%)';[...dt.children].forEach((d,j)=>d.classList.toggle('on',j==k))}
const play=()=>{clearInterval(tm);if(!matchMedia('(prefers-reduced-motion:reduce)').matches)tm=setInterval(()=>go(k+1),4000)};
g.querySelector('.l').onclick=()=>{go(k-1);play()};g.querySelector('.r').onclick=()=>{go(k+1);play()};
g.onmouseenter=()=>clearInterval(tm);g.onmouseleave=play;
let x0=null;g.ontouchstart=e=>{x0=e.touches[0].clientX;clearInterval(tm)};g.ontouchend=e=>{if(x0!==null){const dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>40)go(k+(dx<0?1:-1))}x0=null;play()};
go(0);play()})();
$('#lb').onclick=()=>$('#lb').classList.remove('on');addEventListener('keydown',e=>e.key=='Escape'&&$('#lb').classList.remove('on'));

// ===== SAVINGS ESTIMATOR (assumes Rs 8 per unit and 130 units per kW per month) =====
const bill=$('#bill'),fm=n=>Math.round(n).toLocaleString('en-IN');
function calc(){const v=+bill.value,u=v/8,k=Math.max(1,Math.ceil(u/130));$('#bv').textContent='₹'+fm(v);$('#kw').textContent=k+' kW';$('#gen').textContent=fm(k*130);$('#sav').textContent='₹'+fm(Math.min(v,k*130*8))}
bill.oninput=calc;calc();
const mb=$('.burger'),mn=$('#menu');mb.onclick=()=>{const o=mn.classList.toggle('open');mb.setAttribute('aria-expanded',o)};mn.onclick=()=>mn.classList.remove('open');
const links=[...document.querySelectorAll('a.l')];
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle('on',a.hash=='#'+e.target.id));document.querySelectorAll('.tabbar a').forEach(a=>a.classList.toggle('on',a.hash=='#'+e.target.id));pos()}),{rootMargin:'-45% 0px -50% 0px'});
['home','about','products','clients','contact'].forEach(id=>io.observe($('#'+id)));
addEventListener('scroll',()=>{const d=document.documentElement;document.body.classList.toggle('sc',d.scrollTop>60);$('#top').style.width=(d.scrollTop/(d.scrollHeight-d.clientHeight)*100)+'%'},{passive:true});
$('#cf').onsubmit=async e=>{
 const v=e.submitter.dataset.v,d={name:$('#n').value,phone:$('#p').value,email:$('#e').value,type:$('#t').value,message:$('#m').value};
 if(v=='wa'){e.preventDefault();const t=`New enquiry from website\nName: ${d.name}\nPhone: ${d.phone}\nEmail: ${d.email||'-'}\nProperty: ${d.type}\nRequirement: ${d.message||'-'}`;open('https://wa.me/'+CONFIG.WHATSAPP+'?text='+encodeURIComponent(t),'_blank');$('#msg').textContent='WhatsApp is open with your details. Press send there to reach us.';return}
 if(!CONFIG.API_URL)return; /* no backend set: the form posts to FormSubmit (see form action in index.html) */
 e.preventDefault();$('#msg').textContent='Sending...';
 try{const r=await fetch(CONFIG.API_URL+'/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}),x=await r.json().catch(()=>({}));
  if(r.ok){$('#msg').textContent='Thank you! We will call you back soon.';e.target.reset()}else $('#msg').textContent=x.error||'Could not send. Please call us on +91 86602 68890.'}
 catch(_){$('#msg').textContent='Could not send. Please call us on +91 86602 68890.'}};

const ind=H('span','');ind.id='ind';mn.prepend(ind);
function pos(){const a=document.querySelector('#menu a.l.on');if(!a){ind.style.width='0';return}ind.style.left=a.offsetLeft+'px';ind.style.width=a.offsetWidth+'px'}
addEventListener('resize',pos);
[["home","Home","#home"],["users","About","#about"],["zap","Products","#products"],["bld","Clients","#clients"],["phone","Contact","#contact"]].forEach(t=>$('#tb').append(H('a','',ic(t[0])+'<span>'+t[1]+'</span>')));
document.querySelectorAll('#tb a').forEach((a,i)=>a.href=['#home','#about','#products','#clients','#contact'][i]);
