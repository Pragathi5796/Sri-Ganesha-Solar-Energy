# Sri Ganesha Solar Energy - website project

## Folder map
frontend/
  index.html        PAGE CONTENT: text, sections, phone, email, address, form
  css/style.css     LOOK: colours, fonts, layout, mobile view (colour settings: "THEME v2" block at the bottom)
  js/config.js      SETTINGS: WhatsApp number, company email, backend address (API_URL)
  js/data.js        CONTENT LISTS: services, benefits, customer types, Tata tabs, clients table, gallery photos, icons
  js/script.js      BEHAVIOUR: menu, tabs, photo slider, savings estimator, contact form sending
  images/           logo.png, hero-1.jpg (homepage picture), photo-1..5.jpg (gallery), clients/ (logos)
backend/
  server.js         BACKEND: receives the contact form, saves it, emails the company
  package.json      backend packages
  .env.example      copy to .env and add the Gmail app password
  README.md         how to run and deploy the backend

## What to edit for what
| I want to change...                      | Edit this file                         |
|------------------------------------------|----------------------------------------|
| Phone, email, address                    | index.html (links and Contact section) and js/config.js |
| Headline, About text, section text       | index.html                             |
| Services, benefits, clients, gallery     | js/data.js                             |
| Colours, fonts, spacing, mobile layout   | css/style.css                          |
| Homepage background picture              | replace images/hero-1.jpg              |
| Logo                                     | replace images/logo.png                |
| Savings estimator numbers (Rs 8/unit, 130 units per kW) | js/script.js (search "bill") |
| Where form enquiries go                  | backend/server.js and backend/.env     |

## Run in VS Code
Website only: open the `frontend` folder, right-click index.html > Open with Live Server (Live Server extension).
Website + working form email: see backend/README.md (`cd backend`, `npm install`, `npm start`, open http://localhost:3000).

## Publish
Website only: drag the `frontend` folder contents into Netlify (index.html must be at the top level). The form then uses FormSubmit (API_URL empty).
With backend: deploy `backend` to a Node.js host, set API_URL in js/config.js, then upload the frontend.
