# Backend (contact form)

What it does: receives the Contact Us form, saves a backup of every enquiry in `backend/data/leads.jsonl`, and emails it to the company.

## Run it (VS Code terminal)
1. `cd backend`
2. `npm install`           (first time only; needs Node.js from nodejs.org)
3. Copy `.env.example` to `.env` and fill in SMTP_PASS (see below)
4. `npm start`
5. Open http://localhost:3000 - the website opens, and the form now sends real email.
6. In `frontend/js/config.js` set `API_URL:'http://localhost:3000'` if you open the site some other way (for example Live Server).

## Gmail password (SMTP_PASS)
Turn on 2-Step Verification for sriganeshasolarenergy@gmail.com, then create an "App password" in your Google account security settings and paste it in `.env`. Do not use the normal Gmail password.

## Put it online
Deploy the `backend` folder to any Node.js host (Render, Railway, a VPS, etc.). Add the values from `.env` in the host's settings. Then set `API_URL` in `frontend/js/config.js` to the backend address and set `ALLOWED_ORIGIN` to your website address.

## Upgrade ideas
- Automatic WhatsApp message to the company: needs the WhatsApp Business Cloud API (approved message template). Add the call in the `/api/contact` route in `server.js`.
- Save leads to a database or Google Sheet instead of a file.
- Add a simple admin page to view leads.
