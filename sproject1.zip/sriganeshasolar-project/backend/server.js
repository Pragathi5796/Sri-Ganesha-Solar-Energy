// Sri Ganesha Solar Energy - backend
// Receives the Contact Us form, saves the lead, and emails it to the company.
// It also serves the website from ../frontend so one command runs everything.
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const TO = process.env.COMPANY_EMAIL || 'sriganeshasolarenergy@gmail.com';
const LEADS = path.join(__dirname, 'data', 'leads.jsonl');   // backup copy of every enquiry

app.set('trust proxy', 1);
app.use(express.json({ limit: '20kb' }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(',') : true }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Allow at most 5 enquiries per visitor every 10 minutes (stops spam)
const hits = new Map();
function limited(ip) {
  const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 600000);
  a.push(now); hits.set(ip, a); return a.length > 5;
}

const mailer = process.env.SMTP_USER && process.env.SMTP_PASS
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: Number(process.env.SMTP_PORT || 465),
      secure: String(process.env.SMTP_PORT || 465) === '465',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    })
  : null;

const clean = (s, n = 500) => String(s || '').replace(/[\r\n]+/g, ' ').trim().slice(0, n);

app.get('/api/health', (req, res) => res.json({ ok: true, email: mailer ? 'configured' : 'not configured (leads are only saved to a file)' }));

app.post('/api/contact', async (req, res) => {
  const b = req.body || {};
  if (b.website) return res.json({ ok: true });                       // hidden spam trap
  if (limited(req.ip)) return res.status(429).json({ error: 'Too many requests. Please try again later.' });

  const lead = {
    name: clean(b.name, 100), phone: clean(b.phone, 20), email: clean(b.email, 120),
    type: clean(b.type, 60), message: clean(b.message, 1000), time: new Date().toISOString()
  };
  if (lead.name.length < 2 || !/^\+?[\d\s-]{8,18}$/.test(lead.phone))
    return res.status(400).json({ error: 'Please enter your name and a valid phone number.' });

  try {                                                               // 1. keep a backup copy
    fs.mkdirSync(path.dirname(LEADS), { recursive: true });
    fs.appendFileSync(LEADS, JSON.stringify(lead) + '\n');
  } catch (e) { console.error('Could not save lead:', e.message); }

  const text = `New enquiry from the website\n\nName: ${lead.name}\nPhone: ${lead.phone}\nEmail: ${lead.email || '-'}\nProperty type: ${lead.type}\nRequirement: ${lead.message || '-'}\nTime: ${lead.time}`;
  if (!mailer) { console.log('\n' + text + '\n(Email not configured - set SMTP_USER and SMTP_PASS in .env)'); return res.json({ ok: true }); }

  try {                                                               // 2. email the company
    await mailer.sendMail({
      from: `"Sri Ganesha Solar website" <${process.env.SMTP_USER}>`, to: TO,
      replyTo: /^\S+@\S+\.\S+$/.test(lead.email) ? lead.email : undefined,
      subject: `New solar enquiry: ${lead.name} (${lead.phone})`, text
    });
    res.json({ ok: true });
  } catch (e) {
    console.error('Email failed:', e.message);
    res.status(502).json({ error: 'Sorry, we could not send your enquiry. Please call us on +91 86602 68890.' });
  }
});

app.listen(PORT, () => console.log(`Sri Ganesha Solar running at http://localhost:${PORT}`));
